﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace UÇBET
{
    public partial class Anasayfafrm : Form
    {


        public Anasayfafrm()
        {
            InitializeComponent();
        }

        private void btnhesabım_Click(object sender, EventArgs e)
        {



        }
        
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        

        int dosyaartisi = 0;
        string yol;
        private void btngeri_Click(object sender, EventArgs e)
        {
            if (dosyaartisi>files.Count-1)
            {

                files.Clear();
                foreach (var dosya in dosyalar)
                {
                    files.Add(dosya);
                }
                dosyaartisi = 0;
            }
            
            
            
            pcrAnsfkampanya.ImageLocation = (string)files[dosyaartisi];
            
            yol = (string)files[dosyaartisi];

            dosyaartisi++;
           

        }

        private void btnileri_Click(object sender, EventArgs e)
        {
            pcrAnsfkampanya.ImageLocation = yol;
        }
        
        private void btngeri_MouseEnter(object sender, EventArgs e)
        {
            btngeri.BackColor = Color.DarkRed;
        }

        private void btngeri_MouseLeave(object sender, EventArgs e)
        {
            btngeri.BackColor = Color.Red;
        }

        private void panelansf_Paint(object sender, PaintEventArgs e)
        {

        }
        ArrayList files= new ArrayList();
        string[] dosyalar;
        string dosyaYolu = @"C:\Users\Lenovo\OneDrive\Masaüstü\Udemy Projeleri\UÇBET\UÇBET\Resimler\Kampanyalar\";
        private void Anasayfafrm_Load(object sender, EventArgs e)
        {

            dosyalar= Directory.GetFiles(dosyaYolu);
            foreach (var dosya in dosyalar)
            {
                files.Add(dosya);//
            }
            Random rnd = new Random();
            int i = rnd.Next(0, files.Count);
            pcrAnsfkampanya.ImageLocation = (string)files[i];
            
            

            
        }

        private void ansfkampanya_Click(object sender, EventArgs e)
        {
            
        }

        private void ansfkampanya_MouseClick(object sender, MouseEventArgs e)
        {
            //buraya tıklandığında kampanya bilgi formu açılacak 

        }
    }
}
