﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UÇBET
{
    public partial class Menufrm : Form
    {
        public Menufrm()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
            
        }

        private void Menufrm_Load(object sender, EventArgs e)
        {
            
        }

        private void btnanasayfa_Click(object sender, EventArgs e)
        {
            butonpnl.Controls.Clear();
            Anasayfafrm ansf = new Anasayfafrm();
            ansf.MdiParent = this;
            butonpnl.Controls.Add(ansf);
            ansf.Show();
            ansf.Dock = DockStyle.Fill;
            ansf.BringToFront();
        }


        private void btnkampanya_Click_1(object sender, EventArgs e)
        {
            butonpnl.Controls.Clear();
            Kampanyafrm kmpn = new Kampanyafrm();
            kmpn.MdiParent = this;
            butonpnl.Controls.Add(kmpn);
            kmpn.Show();
            kmpn.Dock = DockStyle.Fill;
            kmpn.BringToFront();


        }

        private void btnbilet_Click(object sender, EventArgs e)
        {
            butonpnl.Controls.Clear();
            Ucuslarım blt = new Ucuslarım();
            blt.MdiParent = this;
            butonpnl.Controls.Add(blt);
            blt.Show();
            blt.Dock = DockStyle.Fill;
            blt.BringToFront();
        }

     
       

        private void btncıkıs_Click(object sender, EventArgs e)
        {
            DialogResult tus;
            tus = MessageBox.Show("Çıkmak istediğinize emin misiniz?", "Soru", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tus == DialogResult.Yes)
            {
                Close();

            }
            Gırısfrm grs = new Gırısfrm();
            grs.Show();

        }

        private void Menufrm_Load_1(object sender, EventArgs e)
        {
           
          
        }

    }
}
