﻿
namespace UÇBET
{
    partial class Gırısfrm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Gırısfrm));
            this.anagrs = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.girisbox = new System.Windows.Forms.GroupBox();
            this.sfrunuttum = new System.Windows.Forms.Button();
            this.uyekyt = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.sfrgoster = new System.Windows.Forms.CheckBox();
            this.grsbtn = new System.Windows.Forms.Button();
            this.txtsfr = new System.Windows.Forms.TextBox();
            this.txtkuladi = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.anagrs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.girisbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // anagrs
            // 
            this.anagrs.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("anagrs.BackgroundImage")));
            this.anagrs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.anagrs.Controls.Add(this.pictureBox5);
            this.anagrs.Controls.Add(this.girisbox);
            this.anagrs.Controls.Add(this.pictureBox1);
            this.anagrs.Location = new System.Drawing.Point(0, -5);
            this.anagrs.Name = "anagrs";
            this.anagrs.Size = new System.Drawing.Size(603, 840);
            this.anagrs.TabIndex = 0;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(-170, -41);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(559, 286);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 3;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // girisbox
            // 
            this.girisbox.BackColor = System.Drawing.Color.Transparent;
            this.girisbox.Controls.Add(this.sfrunuttum);
            this.girisbox.Controls.Add(this.uyekyt);
            this.girisbox.Controls.Add(this.pictureBox4);
            this.girisbox.Controls.Add(this.pictureBox3);
            this.girisbox.Controls.Add(this.pictureBox2);
            this.girisbox.Controls.Add(this.sfrgoster);
            this.girisbox.Controls.Add(this.grsbtn);
            this.girisbox.Controls.Add(this.txtsfr);
            this.girisbox.Controls.Add(this.txtkuladi);
            this.girisbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.girisbox.Location = new System.Drawing.Point(139, 273);
            this.girisbox.Name = "girisbox";
            this.girisbox.Size = new System.Drawing.Size(340, 522);
            this.girisbox.TabIndex = 2;
            this.girisbox.TabStop = false;
            // 
            // sfrunuttum
            // 
            this.sfrunuttum.BackColor = System.Drawing.Color.Transparent;
            this.sfrunuttum.FlatAppearance.BorderSize = 0;
            this.sfrunuttum.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sfrunuttum.Font = new System.Drawing.Font("Tw Cen MT Condensed", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.sfrunuttum.Location = new System.Drawing.Point(168, 320);
            this.sfrunuttum.Name = "sfrunuttum";
            this.sfrunuttum.Size = new System.Drawing.Size(127, 29);
            this.sfrunuttum.TabIndex = 3;
            this.sfrunuttum.Text = "Şifremi Unuttum";
            this.sfrunuttum.UseVisualStyleBackColor = false;
            this.sfrunuttum.Click += new System.EventHandler(this.sfrunuttum_Click);
            // 
            // uyekyt
            // 
            this.uyekyt.BackColor = System.Drawing.Color.Goldenrod;
            this.uyekyt.ForeColor = System.Drawing.Color.White;
            this.uyekyt.Location = new System.Drawing.Point(77, 451);
            this.uyekyt.Name = "uyekyt";
            this.uyekyt.Size = new System.Drawing.Size(181, 39);
            this.uyekyt.TabIndex = 4;
            this.uyekyt.Text = "Üye Olun";
            this.uyekyt.UseVisualStyleBackColor = false;
            this.uyekyt.Click += new System.EventHandler(this.uyekyt_Click);
            this.uyekyt.MouseEnter += new System.EventHandler(this.uyekyt_MouseEnter);
            this.uyekyt.MouseLeave += new System.EventHandler(this.uyekyt_MouseLeave);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(56, 259);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(23, 26);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(55, 187);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(24, 26);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(55, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(232, 183);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // sfrgoster
            // 
            this.sfrgoster.AutoSize = true;
            this.sfrgoster.BackColor = System.Drawing.Color.Transparent;
            this.sfrgoster.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.sfrgoster.Location = new System.Drawing.Point(56, 327);
            this.sfrgoster.Name = "sfrgoster";
            this.sfrgoster.Size = new System.Drawing.Size(106, 21);
            this.sfrgoster.TabIndex = 5;
            this.sfrgoster.Text = "Şifre göster";
            this.sfrgoster.UseVisualStyleBackColor = false;
            this.sfrgoster.CheckedChanged += new System.EventHandler(this.sfrgoster_CheckedChanged);
            // 
            // grsbtn
            // 
            this.grsbtn.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.grsbtn.ForeColor = System.Drawing.Color.White;
            this.grsbtn.Location = new System.Drawing.Point(77, 386);
            this.grsbtn.Name = "grsbtn";
            this.grsbtn.Size = new System.Drawing.Size(181, 43);
            this.grsbtn.TabIndex = 4;
            this.grsbtn.Text = "Giriş Yap";
            this.grsbtn.UseVisualStyleBackColor = false;
            this.grsbtn.Click += new System.EventHandler(this.grsbtn_Click);
            this.grsbtn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.grsbtn_MouseClick);
            this.grsbtn.MouseEnter += new System.EventHandler(this.grsbtn_MouseEnter);
            this.grsbtn.MouseLeave += new System.EventHandler(this.grsbtn_MouseLeave);
            // 
            // txtsfr
            // 
            this.txtsfr.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.txtsfr.ForeColor = System.Drawing.Color.Silver;
            this.txtsfr.Location = new System.Drawing.Point(77, 259);
            this.txtsfr.Name = "txtsfr";
            this.txtsfr.Size = new System.Drawing.Size(204, 26);
            this.txtsfr.TabIndex = 1;
            this.txtsfr.Text = "Şifre";
            // 
            // txtkuladi
            // 
            this.txtkuladi.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.txtkuladi.ForeColor = System.Drawing.Color.Silver;
            this.txtkuladi.Location = new System.Drawing.Point(77, 187);
            this.txtkuladi.Name = "txtkuladi";
            this.txtkuladi.Size = new System.Drawing.Size(204, 26);
            this.txtkuladi.TabIndex = 0;
            this.txtkuladi.Text = "Kullanıcı adı";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(390, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(212, 204);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // ımageList1
            // 
            this.ımageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "1672672907434.png");
            this.ımageList1.Images.SetKeyName(1, "pngegg (1).png");
            this.ımageList1.Images.SetKeyName(2, "pngegg (2).png");
            // 
            // Gırısfrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 834);
            this.Controls.Add(this.anagrs);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Gırısfrm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Girisfrm_FormClosing);
            this.Load += new System.EventHandler(this.Girisfrm_Load);
            this.anagrs.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.girisbox.ResumeLayout(false);
            this.girisbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel anagrs;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox girisbox;
        private System.Windows.Forms.Button grsbtn;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.TextBox txtsfr;
        private System.Windows.Forms.TextBox txtkuladi;
        private System.Windows.Forms.CheckBox sfrgoster;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button sfrunuttum;
        private System.Windows.Forms.Button uyekyt;
        private System.Windows.Forms.PictureBox pictureBox5;
    }
}

