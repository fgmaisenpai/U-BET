﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace UÇBET
{
  
    public partial class Gırısfrm : Form
    {
        public Gırısfrm()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
        }

        private void grsbtn_MouseEnter(object sender, EventArgs e)
        {
            grsbtn.BackColor = Color.DarkGreen;
        }

        private void grsbtn_MouseLeave(object sender, EventArgs e)
        {
           grsbtn.BackColor = Color.MediumSeaGreen;
        }

        private void sfrgoster_Click(object sender, EventArgs e)
        {
           
        }

        private void sfrgoster_MouseClick(object sender, MouseEventArgs e)
        {
           
        }

        private void sfrgoster_CheckedChanged(object sender, EventArgs e)
        {
            if (sfrgoster.Checked)
            {
                txtsfr.PasswordChar = '\0';

            }
            else 
            {
                txtsfr.PasswordChar = '*';
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void uyekyt_MouseEnter(object sender, EventArgs e)
        {
            uyekyt.BackColor = Color.OrangeRed;
        }

        private void uyekyt_MouseLeave(object sender, EventArgs e)
        {
            uyekyt.BackColor = Color.DarkOrange;
        }

        private void grsbtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("HOŞGELDİNİZ");

            Menufrm mnu = new Menufrm();
            mnu.Show();
            this.Hide();


        }

        private void grsbtn_MouseClick(object sender, MouseEventArgs e)
        {
            
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void Girisfrm_Load(object sender, EventArgs e)
        {

        }

        private void Girisfrm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void uyekyt_Click(object sender, EventArgs e)
        {
            anagrs.Controls.Clear();
            UyeKayıt kyt = new UyeKayıt();
            kyt.MdiParent = this;
            anagrs.Controls.Add(kyt);
            kyt.Show();
            kyt.Dock = DockStyle.Fill;
            kyt.BringToFront();
        }

        private void sfrunuttum_Click(object sender, EventArgs e)
        {
            anagrs.Controls.Clear();
            Sifremiunuttum sfr = new Sifremiunuttum();
            sfr.MdiParent = this;
            anagrs.Controls.Add(sfr);
            sfr.Show();
            sfr.Dock = DockStyle.Fill;
            sfr.BringToFront();
        }
    }
}
