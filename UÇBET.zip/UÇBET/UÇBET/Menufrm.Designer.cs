﻿
namespace UÇBET
{
    partial class Menufrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menufrm));
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.mnupnl1 = new System.Windows.Forms.Panel();
            this.butonpnl = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btncıkıs = new System.Windows.Forms.Button();
            this.ımageList3 = new System.Windows.Forms.ImageList(this.components);
            this.btnanasayfa = new System.Windows.Forms.Button();
            this.btnbilet = new System.Windows.Forms.Button();
            this.btnkampanya = new System.Windows.Forms.Button();
            this.ımageList2 = new System.Windows.Forms.ImageList(this.components);
            this.mnupnl1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ımageList1
            // 
            this.ımageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "pngwing.com (4).png");
            this.ımageList1.Images.SetKeyName(1, "pngwing.com (9).png");
            // 
            // mnupnl1
            // 
            this.mnupnl1.Controls.Add(this.butonpnl);
            this.mnupnl1.Controls.Add(this.panel1);
            this.mnupnl1.Location = new System.Drawing.Point(1, 0);
            this.mnupnl1.Name = "mnupnl1";
            this.mnupnl1.Size = new System.Drawing.Size(601, 800);
            this.mnupnl1.TabIndex = 0;
            // 
            // butonpnl
            // 
            this.butonpnl.Location = new System.Drawing.Point(0, 3);
            this.butonpnl.Name = "butonpnl";
            this.butonpnl.Size = new System.Drawing.Size(601, 684);
            this.butonpnl.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.btncıkıs);
            this.panel1.Controls.Add(this.btnanasayfa);
            this.panel1.Controls.Add(this.btnbilet);
            this.panel1.Controls.Add(this.btnkampanya);
            this.panel1.Location = new System.Drawing.Point(0, 687);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(604, 84);
            this.panel1.TabIndex = 5;
            // 
            // btncıkıs
            // 
            this.btncıkıs.BackColor = System.Drawing.Color.Transparent;
            this.btncıkıs.FlatAppearance.BorderSize = 0;
            this.btncıkıs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncıkıs.Font = new System.Drawing.Font("Microsoft PhagsPa", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btncıkıs.ImageKey = "pngwing.com (4).png";
            this.btncıkıs.ImageList = this.ımageList3;
            this.btncıkıs.Location = new System.Drawing.Point(518, 10);
            this.btncıkıs.Name = "btncıkıs";
            this.btncıkıs.Size = new System.Drawing.Size(61, 70);
            this.btncıkıs.TabIndex = 1;
            this.btncıkıs.Text = "                      Çıkış";
            this.btncıkıs.UseVisualStyleBackColor = false;
            this.btncıkıs.Click += new System.EventHandler(this.btncıkıs_Click);
            // 
            // ımageList3
            // 
            this.ımageList3.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.ımageList3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList3.ImageStream")));
            this.ımageList3.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList3.Images.SetKeyName(0, "pngwing.com (17).png");
            this.ımageList3.Images.SetKeyName(1, "pngwing.com (15).png");
            this.ımageList3.Images.SetKeyName(2, "pngwing.com 8.png");
            this.ımageList3.Images.SetKeyName(3, "pngwing.com (4).png");
            // 
            // btnanasayfa
            // 
            this.btnanasayfa.BackColor = System.Drawing.Color.Transparent;
            this.btnanasayfa.FlatAppearance.BorderSize = 0;
            this.btnanasayfa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnanasayfa.Font = new System.Drawing.Font("Microsoft PhagsPa", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnanasayfa.ImageKey = "pngwing.com (17).png";
            this.btnanasayfa.ImageList = this.ımageList3;
            this.btnanasayfa.Location = new System.Drawing.Point(39, 10);
            this.btnanasayfa.Name = "btnanasayfa";
            this.btnanasayfa.Size = new System.Drawing.Size(94, 68);
            this.btnanasayfa.TabIndex = 0;
            this.btnanasayfa.Text = "                            Anasayfa";
            this.btnanasayfa.UseVisualStyleBackColor = false;
            this.btnanasayfa.Click += new System.EventHandler(this.btnanasayfa_Click);
            // 
            // btnbilet
            // 
            this.btnbilet.BackColor = System.Drawing.Color.Transparent;
            this.btnbilet.FlatAppearance.BorderSize = 0;
            this.btnbilet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbilet.Font = new System.Drawing.Font("Microsoft PhagsPa", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnbilet.ImageKey = "pngwing.com (9).png";
            this.btnbilet.ImageList = this.ımageList1;
            this.btnbilet.Location = new System.Drawing.Point(339, 9);
            this.btnbilet.Name = "btnbilet";
            this.btnbilet.Size = new System.Drawing.Size(150, 71);
            this.btnbilet.TabIndex = 2;
            this.btnbilet.Text = "                                                                    Uçuşlarım";
            this.btnbilet.UseVisualStyleBackColor = false;
            this.btnbilet.Click += new System.EventHandler(this.btnbilet_Click);
            // 
            // btnkampanya
            // 
            this.btnkampanya.BackColor = System.Drawing.Color.Transparent;
            this.btnkampanya.FlatAppearance.BorderSize = 0;
            this.btnkampanya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnkampanya.Font = new System.Drawing.Font("Microsoft PhagsPa", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnkampanya.ImageKey = "pngwing.com (18).png";
            this.btnkampanya.ImageList = this.ımageList2;
            this.btnkampanya.Location = new System.Drawing.Point(168, 9);
            this.btnkampanya.Name = "btnkampanya";
            this.btnkampanya.Size = new System.Drawing.Size(151, 71);
            this.btnkampanya.TabIndex = 1;
            this.btnkampanya.Text = "                                                                   Kampanyalar";
            this.btnkampanya.UseVisualStyleBackColor = false;
            this.btnkampanya.Click += new System.EventHandler(this.btnkampanya_Click_1);
            // 
            // ımageList2
            // 
            this.ımageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.ımageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList2.ImageStream")));
            this.ımageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList2.Images.SetKeyName(0, "pngwing.com (33).png");
            this.ımageList2.Images.SetKeyName(1, "pngwing.com (4).png");
            this.ımageList2.Images.SetKeyName(2, "pngwing.com (18).png");
            this.ımageList2.Images.SetKeyName(3, "pngwing.com (9).png");
            this.ımageList2.Images.SetKeyName(4, "pngwing.com (15).png");
            // 
            // Menufrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 800);
            this.Controls.Add(this.mnupnl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Menufrm";
            this.Text = "                                      ";
            this.Load += new System.EventHandler(this.Menufrm_Load_1);
            this.mnupnl1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Panel mnupnl1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel butonpnl;
        private System.Windows.Forms.Button btncıkıs;
        private System.Windows.Forms.ImageList ımageList2;
        private System.Windows.Forms.ImageList ımageList3;
        private System.Windows.Forms.Button btnbilet;
        private System.Windows.Forms.Button btnkampanya;
        private System.Windows.Forms.Button btnanasayfa;
    }
}