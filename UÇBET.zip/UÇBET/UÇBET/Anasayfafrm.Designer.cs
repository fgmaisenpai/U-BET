﻿
namespace UÇBET
{
    partial class Anasayfafrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Anasayfafrm));
            this.ımageList4 = new System.Windows.Forms.ImageList(this.components);
            this.ımageList3 = new System.Windows.Forms.ImageList(this.components);
            this.hsbmpanel = new System.Windows.Forms.Panel();
            this.btngeri = new System.Windows.Forms.Button();
            this.btnileri = new System.Windows.Forms.Button();
            this.pcrAnsfkampanya = new System.Windows.Forms.PictureBox();
            this.btnhesabım = new System.Windows.Forms.Button();
            this.hsbmpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcrAnsfkampanya)).BeginInit();
            this.SuspendLayout();
            // 
            // ımageList4
            // 
            this.ımageList4.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.ımageList4.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList4.ImageStream")));
            this.ımageList4.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList4.Images.SetKeyName(0, "pngwing.com (9).png");
            this.ımageList4.Images.SetKeyName(1, "111.png");
            this.ımageList4.Images.SetKeyName(2, "2222.png");
            // 
            // ımageList3
            // 
            this.ımageList3.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.ımageList3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList3.ImageStream")));
            this.ımageList3.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList3.Images.SetKeyName(0, "pngwing.com (33).png");
            // 
            // hsbmpanel
            // 
            this.hsbmpanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("hsbmpanel.BackgroundImage")));
            this.hsbmpanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hsbmpanel.Controls.Add(this.btngeri);
            this.hsbmpanel.Controls.Add(this.btnileri);
            this.hsbmpanel.Controls.Add(this.pcrAnsfkampanya);
            this.hsbmpanel.Controls.Add(this.btnhesabım);
            this.hsbmpanel.Location = new System.Drawing.Point(-5, -2);
            this.hsbmpanel.Name = "hsbmpanel";
            this.hsbmpanel.Size = new System.Drawing.Size(610, 689);
            this.hsbmpanel.TabIndex = 1;
            // 
            // btngeri
            // 
            this.btngeri.BackColor = System.Drawing.Color.Transparent;
            this.btngeri.FlatAppearance.BorderSize = 0;
            this.btngeri.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btngeri.ImageKey = "111.png";
            this.btngeri.ImageList = this.ımageList4;
            this.btngeri.Location = new System.Drawing.Point(41, 337);
            this.btngeri.Name = "btngeri";
            this.btngeri.Size = new System.Drawing.Size(41, 42);
            this.btngeri.TabIndex = 3;
            this.btngeri.UseVisualStyleBackColor = false;
            this.btngeri.Click += new System.EventHandler(this.btngeri_Click);
            this.btngeri.MouseEnter += new System.EventHandler(this.btngeri_MouseEnter);
            this.btngeri.MouseLeave += new System.EventHandler(this.btngeri_MouseLeave);
            // 
            // btnileri
            // 
            this.btnileri.BackColor = System.Drawing.Color.Transparent;
            this.btnileri.FlatAppearance.BorderSize = 0;
            this.btnileri.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnileri.ImageKey = "2222.png";
            this.btnileri.ImageList = this.ımageList4;
            this.btnileri.Location = new System.Drawing.Point(530, 345);
            this.btnileri.Name = "btnileri";
            this.btnileri.Size = new System.Drawing.Size(40, 34);
            this.btnileri.TabIndex = 2;
            this.btnileri.UseVisualStyleBackColor = false;
            this.btnileri.Click += new System.EventHandler(this.btnileri_Click);
            // 
            // pcrAnsfkampanya
            // 
            this.pcrAnsfkampanya.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pcrAnsfkampanya.Location = new System.Drawing.Point(88, 30);
            this.pcrAnsfkampanya.Name = "pcrAnsfkampanya";
            this.pcrAnsfkampanya.Size = new System.Drawing.Size(427, 644);
            this.pcrAnsfkampanya.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrAnsfkampanya.TabIndex = 1;
            this.pcrAnsfkampanya.TabStop = false;
            this.pcrAnsfkampanya.Click += new System.EventHandler(this.ansfkampanya_Click);
            this.pcrAnsfkampanya.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ansfkampanya_MouseClick);
            // 
            // btnhesabım
            // 
            this.btnhesabım.BackColor = System.Drawing.Color.Transparent;
            this.btnhesabım.FlatAppearance.BorderSize = 0;
            this.btnhesabım.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnhesabım.ImageKey = "pngwing.com (33).png";
            this.btnhesabım.ImageList = this.ımageList3;
            this.btnhesabım.Location = new System.Drawing.Point(530, 12);
            this.btnhesabım.Name = "btnhesabım";
            this.btnhesabım.Size = new System.Drawing.Size(58, 73);
            this.btnhesabım.TabIndex = 0;
            this.btnhesabım.UseVisualStyleBackColor = false;
            this.btnhesabım.Click += new System.EventHandler(this.btnhesabım_Click);
            // 
            // Anasayfafrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 684);
            this.Controls.Add(this.hsbmpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Anasayfafrm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Anasayfafrm_Load);
            this.hsbmpanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcrAnsfkampanya)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ImageList ımageList3;
        private System.Windows.Forms.ImageList ımageList4;
        private System.Windows.Forms.Panel hsbmpanel;
        private System.Windows.Forms.Button btngeri;
        private System.Windows.Forms.Button btnileri;
        private System.Windows.Forms.PictureBox pcrAnsfkampanya;
        private System.Windows.Forms.Button btnhesabım;
    }
}