﻿
namespace Ucbet0._1
{
    partial class frmUyeKayıt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUyeKayıt));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pcrGeri = new System.Windows.Forms.PictureBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.mkdboxTC = new System.Windows.Forms.MaskedTextBox();
            this.mkdBoxPasaport = new System.Windows.Forms.MaskedTextBox();
            this.cmbUyruk = new System.Windows.Forms.ComboBox();
            this.dtpDogumT = new System.Windows.Forms.DateTimePicker();
            this.rderkek = new System.Windows.Forms.RadioButton();
            this.rdKadın = new System.Windows.Forms.RadioButton();
            this.rdNone = new System.Windows.Forms.RadioButton();
            this.mkdTelefonNo = new System.Windows.Forms.MaskedTextBox();
            this.txtEposta = new System.Windows.Forms.TextBox();
            this.txtSifre = new System.Windows.Forms.TextBox();
            this.btnKayıt = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcrGeri)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.OrangeRed;
            this.panel1.Controls.Add(this.lbl1);
            this.panel1.Controls.Add(this.pcrGeri);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(604, 69);
            this.panel1.TabIndex = 0;
            // 
            // pcrGeri
            // 
            this.pcrGeri.BackColor = System.Drawing.Color.Transparent;
            this.pcrGeri.Image = ((System.Drawing.Image)(resources.GetObject("pcrGeri.Image")));
            this.pcrGeri.Location = new System.Drawing.Point(11, 21);
            this.pcrGeri.Name = "pcrGeri";
            this.pcrGeri.Size = new System.Drawing.Size(66, 36);
            this.pcrGeri.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrGeri.TabIndex = 0;
            this.pcrGeri.TabStop = false;
            this.pcrGeri.Click += new System.EventHandler(this.pcrGeri_Click);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Nirmala UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(94, 19);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(142, 38);
            this.lbl1.TabIndex = 1;
            this.lbl1.Text = "Üye Kayıt";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(129, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ad :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(106, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Soyad :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(61, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "TC Kimlik No :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(64, 258);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 25);
            this.label4.TabIndex = 4;
            this.label4.Text = "Pasaport No :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(108, 322);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 25);
            this.label5.TabIndex = 5;
            this.label5.Text = "Uyruk :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(57, 389);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 25);
            this.label6.TabIndex = 6;
            this.label6.Text = "Doğum Tarihi :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(96, 458);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 25);
            this.label7.TabIndex = 7;
            this.label7.Text = "Cinsiyet :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(74, 529);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 25);
            this.label8.TabIndex = 8;
            this.label8.Text = "Telefon No :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(104, 595);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 25);
            this.label9.TabIndex = 9;
            this.label9.Text = "Eposta :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(114, 661);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 25);
            this.label10.TabIndex = 10;
            this.label10.Text = "Şifre :";
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(184, 95);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(100, 22);
            this.txtAd.TabIndex = 0;
            // 
            // txtSoyad
            // 
            this.txtSoyad.Location = new System.Drawing.Point(184, 147);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(100, 22);
            this.txtSoyad.TabIndex = 11;
            // 
            // mkdboxTC
            // 
            this.mkdboxTC.Location = new System.Drawing.Point(184, 198);
            this.mkdboxTC.Name = "mkdboxTC";
            this.mkdboxTC.Size = new System.Drawing.Size(100, 22);
            this.mkdboxTC.TabIndex = 12;
            // 
            // mkdBoxPasaport
            // 
            this.mkdBoxPasaport.Location = new System.Drawing.Point(184, 258);
            this.mkdBoxPasaport.Name = "mkdBoxPasaport";
            this.mkdBoxPasaport.Size = new System.Drawing.Size(100, 22);
            this.mkdBoxPasaport.TabIndex = 13;
            // 
            // cmbUyruk
            // 
            this.cmbUyruk.Items.AddRange(new object[] {
            "AFGHANİSTAN\t",
            "ALBANIA\t",
            "ALGERIA\t",
            "ANGOLA\t",
            "ARGENTINA\t",
            "ARMENIA\t",
            "AUSTRALIA\t",
            "AUSTRIA\t",
            "AZERBAIJAN\t",
            "BAHAMAS\t",
            "BAHRAIN\t",
            "BANGLADESH\t",
            "BARBADOS\t",
            "BELARUS\t",
            "BELGIUM\t",
            "BENIN\t",
            "BHUTAN\t",
            "BOLIVIA\t",
            "BOSNIA AND HERZEGOVINA\t",
            "BOTSWANA\t",
            "BRAZIL\t",
            "BULGARIA\t",
            "BURUNDİ\t",
            "CAMBODIA\t",
            "CAMEROON\t",
            "CANADA\t",
            "CAPE VERDE\t",
            "CENTRAL AFRICAN REPUBLIC\t",
            "CHAD\t",
            "CHILE\t",
            "CHINA\t",
            "COLOMBIA\t",
            "COMOROS ISLANDS\t",
            "COSTA RICA\t",
            "COTE D\'LVORIE\t",
            "CROATIA\t",
            "CUBA\t",
            "CZECH REPUBLIC\t",
            "DEMOCRATIC REPUBLIC OF THE CONGO\t",
            "DENMARK\t",
            "DJIBOUTI",
            "DOMINICA\t",
            "DOMINICAN REPUBLIC\t",
            "ECUADOR\t",
            "EGYPT\t",
            "EL SALVADOR\t",
            "EQUATORIAL GUINEA\t",
            "ESTONIA\t",
            "ETHIOPIA\t",
            "FIJI ISLAND\t",
            "FINLAND\t",
            "FRANCE\t",
            "GABON\t",
            "GAMBIA\t",
            "GEORGIA\t",
            "GERMANY\t",
            "GHANA\tGANA",
            "GREECE\t",
            "GRENADA\t",
            "GUATEMALA\t",
            "GUINEA\t",
            "GUINEA-BISSAU\t",
            "HAITI\tHAİTİ",
            "HONDURAS\t",
            "HUNGARY\t",
            "ICELAND\t",
            "INDIA\t",
            "INDONESIA\t",
            "IRAN\t",
            "IRAQ\t",
            "IRELAND\t",
            "ISRAEL\t",
            "ITALY\t",
            "JAMAICA\t",
            "JAPAN\t",
            "JORDAN \t",
            "KAZAKHSTAN\t",
            "KENYA\t",
            "KOREA\t",
            "KOSOVO\t",
            "KUWAIT\t",
            "KYRGYZSTAN\t",
            "LAO PEOPLE\'S DEMOCRATIC REPUBLIC\t",
            "LATVIA\t",
            "LEBANON\t",
            "LESOTHO\t",
            "LIBERIA\t",
            "LIBYA\t",
            "LITHUANIA\t",
            "LUXEMBURG\t",
            "MACEDONIA\t",
            "MADAGASCAR\t",
            "MALAWİ\t",
            "MALAYSIA\t",
            "MALDIVES\t",
            "MALİ\t",
            "MALTA\t",
            "MAURITANIA\t",
            "MAURITIUS\t",
            "MEXICO\t",
            "MOLDOVA\t",
            "MONGOLIA\t",
            "MONTENEGRO\t",
            "MOROCCO\t",
            "MOZAMBIQUE\t",
            "MYANMAR\t",
            "NEPAL\t",
            "NETHERLANDS\t",
            "NEW ZEALAND\t",
            "NICARAGUA\t",
            "NIGER\t",
            "NIGERIA\t",
            "NORWAY\t",
            "OMAN\tUMMAN",
            "PAKISTAN\t",
            "PALESTINE\t",
            "PANAMA\t",
            "PAPUA NEW GUINEA\t",
            "PARAGUAY\t",
            "PEOPLE\'S DEMOCRATIC REPUBLIC OF KOREA\t",
            "PERU\tPERU",
            "PHILIPPINES\t",
            "POLAND\t",
            "PORTUGAL\t",
            "QATAR",
            "ROMANIA\t",
            "RUSSIAN FEDERATION\t",
            "RWANDA\t",
            "SAINT LUCIA\t",
            "SAINT-VINCENT AND GRENADINES\t",
            "SAMOA\t",
            "SAO TOME AND PRINCIPE\t",
            "SAUDI ARABIA\t",
            "SENEGAL\t",
            "SERBIA\t",
            "SEYCHELLES\t",
            "SIERRA LEONE\t",
            "SINGAPORE\t",
            "SLOVAK REPUBLIC\t",
            "SLOVENIA\t",
            "SOLOMON ISLANDS\t",
            "SOMALIA\t",
            "SOUTH AFRICA\t",
            "SPAIN\tİSPANYA",
            "SRI LANKA\t",
            "SUDAN\tSUDAN",
            "SURINAME\t",
            "SWAZILAND\t",
            "SWEDEN\t",
            "SWITZERLAND\t",
            "SYRIA\tSURİYE",
            "TAJIKISTAN\t",
            "TANZANIA\t",
            "THAILAND\t",
            "TOGO\tTOGO",
            "TRINIDAD AND TOBAGO\t",
            "TUNISIA\t",
            "TURKEY\t",
            "TURKMENISTAN\t",
            "UGANDA\t",
            "UKRAINE\t",
            "UNITED ARAB EMIRATES\t",
            "UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IRELAND\t",
            "UNITED STATES OF AMERICA\t",
            "BURKINA FASO\t",
            "URUGUAY\t",
            "UZBEKISTAN\t",
            "VENEZUELA\t",
            "VIETNAM\t",
            "YEMEN\tYEMEN",
            "ZAMBIA\t",
            "ZIMBABWE"});
            this.cmbUyruk.Location = new System.Drawing.Point(184, 322);
            this.cmbUyruk.Name = "cmbUyruk";
            this.cmbUyruk.Size = new System.Drawing.Size(121, 24);
            this.cmbUyruk.TabIndex = 0;
            // 
            // dtpDogumT
            // 
            this.dtpDogumT.Location = new System.Drawing.Point(184, 389);
            this.dtpDogumT.Name = "dtpDogumT";
            this.dtpDogumT.Size = new System.Drawing.Size(200, 22);
            this.dtpDogumT.TabIndex = 0;
            // 
            // rderkek
            // 
            this.rderkek.AutoSize = true;
            this.rderkek.BackColor = System.Drawing.Color.Transparent;
            this.rderkek.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rderkek.Location = new System.Drawing.Point(184, 461);
            this.rderkek.Name = "rderkek";
            this.rderkek.Size = new System.Drawing.Size(70, 29);
            this.rderkek.TabIndex = 14;
            this.rderkek.TabStop = true;
            this.rderkek.Text = "Erkek";
            this.rderkek.UseVisualStyleBackColor = false;
            // 
            // rdKadın
            // 
            this.rdKadın.AutoSize = true;
            this.rdKadın.BackColor = System.Drawing.Color.Transparent;
            this.rdKadın.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdKadın.Location = new System.Drawing.Point(310, 458);
            this.rdKadın.Name = "rdKadın";
            this.rdKadın.Size = new System.Drawing.Size(71, 29);
            this.rdKadın.TabIndex = 15;
            this.rdKadın.TabStop = true;
            this.rdKadın.Text = "Kadın";
            this.rdKadın.UseVisualStyleBackColor = false;
            // 
            // rdNone
            // 
            this.rdNone.AutoSize = true;
            this.rdNone.BackColor = System.Drawing.Color.Transparent;
            this.rdNone.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdNone.Location = new System.Drawing.Point(432, 458);
            this.rdNone.Name = "rdNone";
            this.rdNone.Size = new System.Drawing.Size(69, 29);
            this.rdNone.TabIndex = 16;
            this.rdNone.TabStop = true;
            this.rdNone.Text = "None";
            this.rdNone.UseVisualStyleBackColor = false;
            // 
            // mkdTelefonNo
            // 
            this.mkdTelefonNo.Location = new System.Drawing.Point(184, 529);
            this.mkdTelefonNo.Name = "mkdTelefonNo";
            this.mkdTelefonNo.Size = new System.Drawing.Size(100, 22);
            this.mkdTelefonNo.TabIndex = 17;
            // 
            // txtEposta
            // 
            this.txtEposta.Location = new System.Drawing.Point(184, 595);
            this.txtEposta.Name = "txtEposta";
            this.txtEposta.Size = new System.Drawing.Size(100, 22);
            this.txtEposta.TabIndex = 18;
            // 
            // txtSifre
            // 
            this.txtSifre.Location = new System.Drawing.Point(184, 659);
            this.txtSifre.Name = "txtSifre";
            this.txtSifre.Size = new System.Drawing.Size(100, 22);
            this.txtSifre.TabIndex = 19;
            // 
            // btnKayıt
            // 
            this.btnKayıt.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKayıt.Location = new System.Drawing.Point(242, 723);
            this.btnKayıt.Name = "btnKayıt";
            this.btnKayıt.Size = new System.Drawing.Size(142, 44);
            this.btnKayıt.TabIndex = 20;
            this.btnKayıt.Text = "Kayıt Ol";
            this.btnKayıt.UseVisualStyleBackColor = true;
            this.btnKayıt.Click += new System.EventHandler(this.btnKayıt_Click);
            // 
            // frmUyeKayıt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(603, 800);
            this.Controls.Add(this.btnKayıt);
            this.Controls.Add(this.txtSifre);
            this.Controls.Add(this.txtEposta);
            this.Controls.Add(this.mkdTelefonNo);
            this.Controls.Add(this.rdNone);
            this.Controls.Add(this.rdKadın);
            this.Controls.Add(this.rderkek);
            this.Controls.Add(this.dtpDogumT);
            this.Controls.Add(this.cmbUyruk);
            this.Controls.Add(this.mkdBoxPasaport);
            this.Controls.Add(this.mkdboxTC);
            this.Controls.Add(this.txtSoyad);
            this.Controls.Add(this.txtAd);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmUyeKayıt";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcrGeri)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.PictureBox pcrGeri;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.MaskedTextBox mkdboxTC;
        private System.Windows.Forms.MaskedTextBox mkdBoxPasaport;
        private System.Windows.Forms.ComboBox cmbUyruk;
        private System.Windows.Forms.DateTimePicker dtpDogumT;
        private System.Windows.Forms.RadioButton rderkek;
        private System.Windows.Forms.RadioButton rdKadın;
        private System.Windows.Forms.RadioButton rdNone;
        private System.Windows.Forms.MaskedTextBox mkdTelefonNo;
        private System.Windows.Forms.TextBox txtEposta;
        private System.Windows.Forms.TextBox txtSifre;
        private System.Windows.Forms.Button btnKayıt;
    }
}