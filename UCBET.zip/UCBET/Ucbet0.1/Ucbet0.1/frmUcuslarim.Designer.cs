﻿
namespace Ucbet0._1
{
    partial class frmUcuslarim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUcuslarim));
            this.cmbKalkis = new System.Windows.Forms.ComboBox();
            this.cmbVaris = new System.Windows.Forms.ComboBox();
            this.dtpUcusT = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnUcusAra = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.lblbilet = new System.Windows.Forms.Label();
            this.btnSatinAl = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmbKalkis
            // 
            this.cmbKalkis.FormattingEnabled = true;
            this.cmbKalkis.Items.AddRange(new object[] {
            " Adana",
            " Adıyaman",
            " Afyonkarahisar",
            " Ağrı",
            " Aksaray",
            " Amasya",
            " Ankara",
            " Antalya",
            " Ardahan",
            " Artvin",
            " Aydın",
            " Balıkesir",
            " Bartın",
            " Batman",
            " Bayburt",
            " Bilecik",
            " Bingöl",
            " Bitlis",
            " Bolu",
            " Burdur",
            " Bursa",
            " Çanakkale",
            " Çankırı",
            " Çorum",
            " Denizli",
            " Diyarbakır",
            " Düzce",
            " Edirne",
            " Elazığ",
            " Erzincan",
            " Erzurum",
            " Eskişehir",
            " Gaziantep",
            " Giresun",
            " Gümüşhane",
            " Hakkâri",
            " Hatay",
            " Iğdır",
            " Isparta",
            " İstanbul",
            " İzmir",
            " Kahramanmaraş",
            " Karabük",
            " Karaman",
            " Kars",
            " Kastamonu",
            " Kayseri",
            " Kilis",
            " Kırıkkale",
            " Kırklareli",
            " Kırşehir",
            " Kocaeli",
            " Konya",
            " Kütahya",
            " Malatya",
            " Manisa",
            " Mardin",
            " Mersin",
            " Muğla",
            " Muş",
            " Nevşehir",
            " Niğde",
            " Ordu",
            " Rize",
            " Sakarya",
            " Samsun",
            " Şanlıurfa",
            " Siirt",
            " Sinop",
            " Sivas",
            " Şırnak",
            " Tekirdağ",
            " Tokat",
            " Trabzon",
            " Tunceli",
            " Uşak",
            " Van",
            " Yalova",
            " Yozgat",
            " Zonguldak",
            " Şikago",
            " Boston",
            "New York",
            "Washington D.C",
            "San Francisco",
            "Los Angeles",
            "Miami",
            "San Diego",
            "Houston",
            "Seattle",
            "Philadelphia",
            "Las egas",
            "Austin",
            "Atlanta",
            "Detroit",
            "Baltimore",
            "New Orleans",
            "Dallas",
            "Sacramento",
            "Denver",
            "Virginia Beach",
            "Nashville",
            "Jacksonville",
            "Milwaukee",
            "Minneapolis",
            "San Jose",
            "Portland",
            "Oklahoma City",
            "Pittsburgh",
            "Memphis",
            "Omaha",
            "Kansas City",
            "Phoenix",
            "Cleveland",
            "Albuquerque",
            "Oakland",
            "Columbus",
            "Honolulu",
            "Indıanapolis",
            "St louis",
            "Sait Lake City",
            "San Antonio",
            "Colorado Springs",
            "Charlotte",
            "Louisville",
            "Orlando",
            "Raleigh",
            "Anaheim",
            "Tampa",
            "Tulsa",
            "Wicihita"});
            this.cmbKalkis.Location = new System.Drawing.Point(148, 129);
            this.cmbKalkis.Name = "cmbKalkis";
            this.cmbKalkis.Size = new System.Drawing.Size(121, 24);
            this.cmbKalkis.TabIndex = 0;
            // 
            // cmbVaris
            // 
            this.cmbVaris.FormattingEnabled = true;
            this.cmbVaris.Items.AddRange(new object[] {
            " Adana",
            " Adıyaman",
            " Afyonkarahisar",
            " Ağrı",
            " Aksaray",
            " Amasya",
            " Ankara",
            " Antalya",
            " Ardahan",
            " Artvin",
            " Aydın",
            " Balıkesir",
            " Bartın",
            " Batman",
            " Bayburt",
            " Bilecik",
            " Bingöl",
            " Bitlis",
            " Bolu",
            " Burdur",
            " Bursa",
            " Çanakkale",
            " Çankırı",
            " Çorum",
            " Denizli",
            " Diyarbakır",
            " Düzce",
            " Edirne",
            " Elazığ",
            " Erzincan",
            " Erzurum",
            " Eskişehir",
            " Gaziantep",
            " Giresun",
            " Gümüşhane",
            " Hakkâri",
            " Hatay",
            " Iğdır",
            " Isparta",
            " İstanbul",
            " İzmir",
            " Kahramanmaraş",
            " Karabük",
            " Karaman",
            " Kars",
            " Kastamonu",
            " Kayseri",
            " Kilis",
            " Kırıkkale",
            " Kırklareli",
            " Kırşehir",
            " Kocaeli",
            " Konya",
            " Kütahya",
            " Malatya",
            " Manisa",
            " Mardin",
            " Mersin",
            " Muğla",
            " Muş",
            " Nevşehir",
            " Niğde",
            " Ordu",
            "",
            " Rize",
            " Sakarya",
            " Samsun",
            " Şanlıurfa",
            " Siirt",
            " Sinop",
            " Sivas",
            " Şırnak",
            " Tekirdağ",
            " Tokat",
            " Trabzon",
            " Tunceli",
            " Uşak",
            " Van",
            " Yalova",
            " Yozgat",
            " Zonguldak",
            " Şikago",
            " Boston",
            "New York",
            "Washington D.C",
            "San Francisco",
            "Los Angeles",
            "Miami",
            "San Diego",
            "Houston",
            "Seattle",
            "Philadelphia",
            "Las egas",
            "Austin",
            "Atlanta",
            "Detroit",
            "Baltimore",
            "New Orleans",
            "Dallas",
            "Sacramento",
            "Denver",
            "Virginia Beach",
            "Nashville",
            "Jacksonville",
            "Milwaukee",
            "Minneapolis",
            "San Jose",
            "Portland",
            "Oklahoma City",
            "Pittsburgh",
            "Memphis",
            "Omaha",
            "Kansas City",
            "Phoenix",
            "Cleveland",
            "Albuquerque",
            "Oakland",
            "Columbus",
            "Honolulu",
            "Indıanapolis",
            "St louis",
            "Sait Lake City",
            "San Antonio",
            "Colorado Springs",
            "Charlotte",
            "Louisville",
            "Orlando",
            "Raleigh",
            "Anaheim",
            "Tampa",
            "Tulsa",
            "Wicihita"});
            this.cmbVaris.Location = new System.Drawing.Point(401, 129);
            this.cmbVaris.Name = "cmbVaris";
            this.cmbVaris.Size = new System.Drawing.Size(121, 24);
            this.cmbVaris.TabIndex = 1;
            // 
            // dtpUcusT
            // 
            this.dtpUcusT.Location = new System.Drawing.Point(144, 203);
            this.dtpUcusT.Name = "dtpUcusT";
            this.dtpUcusT.Size = new System.Drawing.Size(200, 22);
            this.dtpUcusT.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(65, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nereden";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(312, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nereye";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Nirmala UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(49, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "Uçuş Tarihi";
            // 
            // btnUcusAra
            // 
            this.btnUcusAra.Location = new System.Drawing.Point(249, 318);
            this.btnUcusAra.Name = "btnUcusAra";
            this.btnUcusAra.Size = new System.Drawing.Size(75, 31);
            this.btnUcusAra.TabIndex = 10;
            this.btnUcusAra.Text = "Ara";
            this.btnUcusAra.UseVisualStyleBackColor = true;
            this.btnUcusAra.Click += new System.EventHandler(this.btnUcusAra_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(605, 72);
            this.panel1.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Nirmala UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(27, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(206, 38);
            this.label6.TabIndex = 0;
            this.label6.Text = "Seyahatini Seç";
            // 
            // lblbilet
            // 
            this.lblbilet.AutoSize = true;
            this.lblbilet.Location = new System.Drawing.Point(246, 535);
            this.lblbilet.Name = "lblbilet";
            this.lblbilet.Size = new System.Drawing.Size(0, 17);
            this.lblbilet.TabIndex = 12;
            // 
            // btnSatinAl
            // 
            this.btnSatinAl.Location = new System.Drawing.Point(249, 621);
            this.btnSatinAl.Name = "btnSatinAl";
            this.btnSatinAl.Size = new System.Drawing.Size(75, 23);
            this.btnSatinAl.TabIndex = 13;
            this.btnSatinAl.Text = "Satın Al";
            this.btnSatinAl.UseVisualStyleBackColor = true;
            this.btnSatinAl.Visible = false;
            // 
            // frmUcuslarim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(603, 709);
            this.Controls.Add(this.btnSatinAl);
            this.Controls.Add(this.lblbilet);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnUcusAra);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dtpUcusT);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbVaris);
            this.Controls.Add(this.cmbKalkis);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmUcuslarim";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbKalkis;
        private System.Windows.Forms.ComboBox cmbVaris;
        private System.Windows.Forms.DateTimePicker dtpUcusT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnUcusAra;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblbilet;
        private System.Windows.Forms.Button btnSatinAl;
    }
}