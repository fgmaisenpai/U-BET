﻿
namespace Ucbet0._1
{
    partial class frmHesabim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHesabim));
            this.txtSifre = new System.Windows.Forms.TextBox();
            this.txtEposta = new System.Windows.Forms.TextBox();
            this.mkdTelefonNo = new System.Windows.Forms.MaskedTextBox();
            this.rdNone = new System.Windows.Forms.RadioButton();
            this.rdKadın = new System.Windows.Forms.RadioButton();
            this.rderkek = new System.Windows.Forms.RadioButton();
            this.dtpDogumT = new System.Windows.Forms.DateTimePicker();
            this.cmbUyruk = new System.Windows.Forms.ComboBox();
            this.mkdBoxPasaport = new System.Windows.Forms.MaskedTextBox();
            this.mkdboxTC = new System.Windows.Forms.MaskedTextBox();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGüncelle = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSil = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSifre
            // 
            this.txtSifre.Location = new System.Drawing.Point(172, 655);
            this.txtSifre.Name = "txtSifre";
            this.txtSifre.Size = new System.Drawing.Size(100, 22);
            this.txtSifre.TabIndex = 41;
            // 
            // txtEposta
            // 
            this.txtEposta.Location = new System.Drawing.Point(172, 591);
            this.txtEposta.Name = "txtEposta";
            this.txtEposta.Size = new System.Drawing.Size(100, 22);
            this.txtEposta.TabIndex = 40;
            // 
            // mkdTelefonNo
            // 
            this.mkdTelefonNo.Location = new System.Drawing.Point(172, 525);
            this.mkdTelefonNo.Name = "mkdTelefonNo";
            this.mkdTelefonNo.Size = new System.Drawing.Size(100, 22);
            this.mkdTelefonNo.TabIndex = 39;
            // 
            // rdNone
            // 
            this.rdNone.AutoSize = true;
            this.rdNone.BackColor = System.Drawing.Color.Transparent;
            this.rdNone.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdNone.Location = new System.Drawing.Point(420, 454);
            this.rdNone.Name = "rdNone";
            this.rdNone.Size = new System.Drawing.Size(69, 29);
            this.rdNone.TabIndex = 38;
            this.rdNone.TabStop = true;
            this.rdNone.Text = "None";
            this.rdNone.UseVisualStyleBackColor = false;
            // 
            // rdKadın
            // 
            this.rdKadın.AutoSize = true;
            this.rdKadın.BackColor = System.Drawing.Color.Transparent;
            this.rdKadın.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdKadın.Location = new System.Drawing.Point(298, 454);
            this.rdKadın.Name = "rdKadın";
            this.rdKadın.Size = new System.Drawing.Size(71, 29);
            this.rdKadın.TabIndex = 37;
            this.rdKadın.TabStop = true;
            this.rdKadın.Text = "Kadın";
            this.rdKadın.UseVisualStyleBackColor = false;
            // 
            // rderkek
            // 
            this.rderkek.AutoSize = true;
            this.rderkek.BackColor = System.Drawing.Color.Transparent;
            this.rderkek.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rderkek.Location = new System.Drawing.Point(172, 457);
            this.rderkek.Name = "rderkek";
            this.rderkek.Size = new System.Drawing.Size(70, 29);
            this.rderkek.TabIndex = 36;
            this.rderkek.TabStop = true;
            this.rderkek.Text = "Erkek";
            this.rderkek.UseVisualStyleBackColor = false;
            // 
            // dtpDogumT
            // 
            this.dtpDogumT.Location = new System.Drawing.Point(172, 385);
            this.dtpDogumT.Name = "dtpDogumT";
            this.dtpDogumT.Size = new System.Drawing.Size(200, 22);
            this.dtpDogumT.TabIndex = 20;
            // 
            // cmbUyruk
            // 
            this.cmbUyruk.Items.AddRange(new object[] {
            "AFGHANİSTAN\t",
            "ALBANIA\t",
            "ALGERIA\t",
            "ANGOLA\t",
            "ARGENTINA\t",
            "ARMENIA\t",
            "AUSTRALIA\t",
            "AUSTRIA\t",
            "AZERBAIJAN\t",
            "BAHAMAS\t",
            "BAHRAIN\t",
            "BANGLADESH\t",
            "BARBADOS\t",
            "BELARUS\t",
            "BELGIUM\t",
            "BENIN\t",
            "BHUTAN\t",
            "BOLIVIA\t",
            "BOSNIA AND HERZEGOVINA\t",
            "BOTSWANA\t",
            "BRAZIL\t",
            "BULGARIA\t",
            "BURUNDİ\t",
            "CAMBODIA\t",
            "CAMEROON\t",
            "CANADA\t",
            "CAPE VERDE\t",
            "CENTRAL AFRICAN REPUBLIC\t",
            "CHAD\t",
            "CHILE\t",
            "CHINA\t",
            "COLOMBIA\t",
            "COMOROS ISLANDS\t",
            "COSTA RICA\t",
            "COTE D\'LVORIE\t",
            "CROATIA\t",
            "CUBA\t",
            "CZECH REPUBLIC\t",
            "DEMOCRATIC REPUBLIC OF THE CONGO\t",
            "DENMARK\t",
            "DJIBOUTI",
            "DOMINICA\t",
            "DOMINICAN REPUBLIC\t",
            "ECUADOR\t",
            "EGYPT\t",
            "EL SALVADOR\t",
            "EQUATORIAL GUINEA\t",
            "ESTONIA\t",
            "ETHIOPIA\t",
            "FIJI ISLAND\t",
            "FINLAND\t",
            "FRANCE\t",
            "GABON\t",
            "GAMBIA\t",
            "GEORGIA\t",
            "GERMANY\t",
            "GHANA\tGANA",
            "GREECE\t",
            "GRENADA\t",
            "GUATEMALA\t",
            "GUINEA\t",
            "GUINEA-BISSAU\t",
            "HAITI\tHAİTİ",
            "HONDURAS\t",
            "HUNGARY\t",
            "ICELAND\t",
            "INDIA\t",
            "INDONESIA\t",
            "IRAN\t",
            "IRAQ\t",
            "IRELAND\t",
            "ISRAEL\t",
            "ITALY\t",
            "JAMAICA\t",
            "JAPAN\t",
            "JORDAN \t",
            "KAZAKHSTAN\t",
            "KENYA\t",
            "KOREA\t",
            "KOSOVO\t",
            "KUWAIT\t",
            "KYRGYZSTAN\t",
            "LAO PEOPLE\'S DEMOCRATIC REPUBLIC\t",
            "LATVIA\t",
            "LEBANON\t",
            "LESOTHO\t",
            "LIBERIA\t",
            "LIBYA\t",
            "LITHUANIA\t",
            "LUXEMBURG\t",
            "MACEDONIA\t",
            "MADAGASCAR\t",
            "MALAWİ\t",
            "MALAYSIA\t",
            "MALDIVES\t",
            "MALİ\t",
            "MALTA\t",
            "MAURITANIA\t",
            "MAURITIUS\t",
            "MEXICO\t",
            "MOLDOVA\t",
            "MONGOLIA\t",
            "MONTENEGRO\t",
            "MOROCCO\t",
            "MOZAMBIQUE\t",
            "MYANMAR\t",
            "NEPAL\t",
            "NETHERLANDS\t",
            "NEW ZEALAND\t",
            "NICARAGUA\t",
            "NIGER\t",
            "NIGERIA\t",
            "NORWAY\t",
            "OMAN\tUMMAN",
            "PAKISTAN\t",
            "PALESTINE\t",
            "PANAMA\t",
            "PAPUA NEW GUINEA\t",
            "PARAGUAY\t",
            "PEOPLE\'S DEMOCRATIC REPUBLIC OF KOREA\t",
            "PERU\tPERU",
            "PHILIPPINES\t",
            "POLAND\t",
            "PORTUGAL\t",
            "QATAR",
            "ROMANIA\t",
            "RUSSIAN FEDERATION\t",
            "RWANDA\t",
            "SAINT LUCIA\t",
            "SAINT-VINCENT AND GRENADINES\t",
            "SAMOA\t",
            "SAO TOME AND PRINCIPE\t",
            "SAUDI ARABIA\t",
            "SENEGAL\t",
            "SERBIA\t",
            "SEYCHELLES\t",
            "SIERRA LEONE\t",
            "SINGAPORE\t",
            "SLOVAK REPUBLIC\t",
            "SLOVENIA\t",
            "SOLOMON ISLANDS\t",
            "SOMALIA\t",
            "SOUTH AFRICA\t",
            "SPAIN\tİSPANYA",
            "SRI LANKA\t",
            "SUDAN\tSUDAN",
            "SURINAME\t",
            "SWAZILAND\t",
            "SWEDEN\t",
            "SWITZERLAND\t",
            "SYRIA\tSURİYE",
            "TAJIKISTAN\t",
            "TANZANIA\t",
            "THAILAND\t",
            "TOGO\tTOGO",
            "TRINIDAD AND TOBAGO\t",
            "TUNISIA\t",
            "TURKEY\t",
            "TURKMENISTAN\t",
            "UGANDA\t",
            "UKRAINE\t",
            "UNITED ARAB EMIRATES\t",
            "UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IRELAND\t",
            "UNITED STATES OF AMERICA\t",
            "BURKINA FASO\t",
            "URUGUAY\t",
            "UZBEKISTAN\t",
            "VENEZUELA\t",
            "VIETNAM\t",
            "YEMEN\tYEMEN",
            "ZAMBIA\t",
            "ZIMBABWE"});
            this.cmbUyruk.Location = new System.Drawing.Point(172, 318);
            this.cmbUyruk.Name = "cmbUyruk";
            this.cmbUyruk.Size = new System.Drawing.Size(121, 24);
            this.cmbUyruk.TabIndex = 21;
            // 
            // mkdBoxPasaport
            // 
            this.mkdBoxPasaport.Location = new System.Drawing.Point(172, 254);
            this.mkdBoxPasaport.Name = "mkdBoxPasaport";
            this.mkdBoxPasaport.Size = new System.Drawing.Size(100, 22);
            this.mkdBoxPasaport.TabIndex = 35;
            // 
            // mkdboxTC
            // 
            this.mkdboxTC.Location = new System.Drawing.Point(172, 194);
            this.mkdboxTC.Name = "mkdboxTC";
            this.mkdboxTC.Size = new System.Drawing.Size(100, 22);
            this.mkdboxTC.TabIndex = 34;
            // 
            // txtSoyad
            // 
            this.txtSoyad.Location = new System.Drawing.Point(172, 143);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(100, 22);
            this.txtSoyad.TabIndex = 33;
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(172, 91);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(100, 22);
            this.txtAd.TabIndex = 22;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(102, 657);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 25);
            this.label10.TabIndex = 32;
            this.label10.Text = "Şifre :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(92, 591);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 25);
            this.label9.TabIndex = 31;
            this.label9.Text = "Eposta :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(62, 525);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 25);
            this.label8.TabIndex = 30;
            this.label8.Text = "Telefon No :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(84, 454);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 25);
            this.label7.TabIndex = 29;
            this.label7.Text = "Cinsiyet :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(45, 385);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 25);
            this.label6.TabIndex = 28;
            this.label6.Text = "Doğum Tarihi :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(96, 318);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 25);
            this.label5.TabIndex = 27;
            this.label5.Text = "Uyruk :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(52, 254);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 25);
            this.label4.TabIndex = 26;
            this.label4.Text = "Pasaport No :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(49, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 25);
            this.label3.TabIndex = 25;
            this.label3.Text = "TC Kimlik No :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(94, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 25);
            this.label2.TabIndex = 24;
            this.label2.Text = "Soyad :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(117, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 25);
            this.label1.TabIndex = 23;
            this.label1.Text = "Ad :";
            // 
            // btnGüncelle
            // 
            this.btnGüncelle.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnGüncelle.FlatAppearance.BorderSize = 2;
            this.btnGüncelle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.btnGüncelle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.btnGüncelle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGüncelle.Font = new System.Drawing.Font("Nirmala UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGüncelle.Location = new System.Drawing.Point(260, 694);
            this.btnGüncelle.Name = "btnGüncelle";
            this.btnGüncelle.Size = new System.Drawing.Size(93, 31);
            this.btnGüncelle.TabIndex = 42;
            this.btnGüncelle.Text = "Güncelle";
            this.btnGüncelle.UseVisualStyleBackColor = true;
            this.btnGüncelle.Click += new System.EventHandler(this.btnGüncelle_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(605, 72);
            this.panel1.TabIndex = 43;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Nirmala UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(94, 18);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(122, 38);
            this.label11.TabIndex = 0;
            this.label11.Text = "Profilim";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(71, 38);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // btnSil
            // 
            this.btnSil.BackColor = System.Drawing.Color.Red;
            this.btnSil.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnSil.FlatAppearance.BorderSize = 2;
            this.btnSil.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.btnSil.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.btnSil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSil.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSil.Location = new System.Drawing.Point(249, 743);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(120, 34);
            this.btnSil.TabIndex = 44;
            this.btnSil.Text = "Hesabımı Sil";
            this.btnSil.UseVisualStyleBackColor = false;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // frmHesabim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(603, 800);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnGüncelle);
            this.Controls.Add(this.txtSifre);
            this.Controls.Add(this.txtEposta);
            this.Controls.Add(this.mkdTelefonNo);
            this.Controls.Add(this.rdNone);
            this.Controls.Add(this.rdKadın);
            this.Controls.Add(this.rderkek);
            this.Controls.Add(this.dtpDogumT);
            this.Controls.Add(this.cmbUyruk);
            this.Controls.Add(this.mkdBoxPasaport);
            this.Controls.Add(this.mkdboxTC);
            this.Controls.Add(this.txtSoyad);
            this.Controls.Add(this.txtAd);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmHesabim";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.frmHesabim_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSifre;
        private System.Windows.Forms.TextBox txtEposta;
        private System.Windows.Forms.MaskedTextBox mkdTelefonNo;
        private System.Windows.Forms.RadioButton rdNone;
        private System.Windows.Forms.RadioButton rdKadın;
        private System.Windows.Forms.RadioButton rderkek;
        private System.Windows.Forms.DateTimePicker dtpDogumT;
        private System.Windows.Forms.ComboBox cmbUyruk;
        private System.Windows.Forms.MaskedTextBox mkdBoxPasaport;
        private System.Windows.Forms.MaskedTextBox mkdboxTC;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGüncelle;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnSil;
    }
}