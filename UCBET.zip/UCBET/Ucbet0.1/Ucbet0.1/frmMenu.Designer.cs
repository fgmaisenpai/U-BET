﻿
namespace Ucbet0._1
{
    partial class frmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMenu));
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.lblÇıkış = new System.Windows.Forms.Label();
            this.lblUcuslarım = new System.Windows.Forms.Label();
            this.lblKampanya = new System.Windows.Forms.Label();
            this.lblanasayfa = new System.Windows.Forms.Label();
            this.pnlButonlar = new System.Windows.Forms.Panel();
            this.pcrCikis = new System.Windows.Forms.PictureBox();
            this.pcrUcuslarim = new System.Windows.Forms.PictureBox();
            this.pcrAnasayfa = new System.Windows.Forms.PictureBox();
            this.pcrKampanya = new System.Windows.Forms.PictureBox();
            this.pnlButonlar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcrCikis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrUcuslarim)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrAnasayfa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrKampanya)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMenu
            // 
            this.pnlMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(603, 709);
            this.pnlMenu.TabIndex = 0;
            // 
            // lblÇıkış
            // 
            this.lblÇıkış.AutoSize = true;
            this.lblÇıkış.BackColor = System.Drawing.Color.Transparent;
            this.lblÇıkış.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblÇıkış.ForeColor = System.Drawing.Color.DimGray;
            this.lblÇıkış.Location = new System.Drawing.Point(494, 61);
            this.lblÇıkış.Name = "lblÇıkış";
            this.lblÇıkış.Size = new System.Drawing.Size(43, 19);
            this.lblÇıkış.TabIndex = 3;
            this.lblÇıkış.Text = "Çıkış";
            // 
            // lblUcuslarım
            // 
            this.lblUcuslarım.AutoSize = true;
            this.lblUcuslarım.BackColor = System.Drawing.Color.Transparent;
            this.lblUcuslarım.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblUcuslarım.ForeColor = System.Drawing.Color.DimGray;
            this.lblUcuslarım.Location = new System.Drawing.Point(324, 61);
            this.lblUcuslarım.Name = "lblUcuslarım";
            this.lblUcuslarım.Size = new System.Drawing.Size(84, 19);
            this.lblUcuslarım.TabIndex = 2;
            this.lblUcuslarım.Text = "Uçuşlarım";
            // 
            // lblKampanya
            // 
            this.lblKampanya.AutoSize = true;
            this.lblKampanya.BackColor = System.Drawing.Color.Transparent;
            this.lblKampanya.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKampanya.ForeColor = System.Drawing.Color.DimGray;
            this.lblKampanya.Location = new System.Drawing.Point(178, 61);
            this.lblKampanya.Name = "lblKampanya";
            this.lblKampanya.Size = new System.Drawing.Size(90, 19);
            this.lblKampanya.TabIndex = 1;
            this.lblKampanya.Text = "Kampanya";
            // 
            // lblanasayfa
            // 
            this.lblanasayfa.AutoSize = true;
            this.lblanasayfa.BackColor = System.Drawing.Color.Transparent;
            this.lblanasayfa.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblanasayfa.ForeColor = System.Drawing.Color.DimGray;
            this.lblanasayfa.Location = new System.Drawing.Point(51, 61);
            this.lblanasayfa.Name = "lblanasayfa";
            this.lblanasayfa.Size = new System.Drawing.Size(79, 19);
            this.lblanasayfa.TabIndex = 0;
            this.lblanasayfa.Text = "Anasayfa";
            // 
            // pnlButonlar
            // 
            this.pnlButonlar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlButonlar.BackgroundImage")));
            this.pnlButonlar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlButonlar.Controls.Add(this.lblÇıkış);
            this.pnlButonlar.Controls.Add(this.pcrCikis);
            this.pnlButonlar.Controls.Add(this.lblUcuslarım);
            this.pnlButonlar.Controls.Add(this.pcrUcuslarim);
            this.pnlButonlar.Controls.Add(this.lblKampanya);
            this.pnlButonlar.Controls.Add(this.pcrAnasayfa);
            this.pnlButonlar.Controls.Add(this.lblanasayfa);
            this.pnlButonlar.Controls.Add(this.pcrKampanya);
            this.pnlButonlar.Location = new System.Drawing.Point(0, 711);
            this.pnlButonlar.Name = "pnlButonlar";
            this.pnlButonlar.Size = new System.Drawing.Size(603, 90);
            this.pnlButonlar.TabIndex = 1;
            // 
            // pcrCikis
            // 
            this.pcrCikis.BackColor = System.Drawing.Color.Transparent;
            this.pcrCikis.Image = ((System.Drawing.Image)(resources.GetObject("pcrCikis.Image")));
            this.pcrCikis.Location = new System.Drawing.Point(490, 3);
            this.pcrCikis.Name = "pcrCikis";
            this.pcrCikis.Size = new System.Drawing.Size(47, 49);
            this.pcrCikis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrCikis.TabIndex = 2;
            this.pcrCikis.TabStop = false;
            this.pcrCikis.Click += new System.EventHandler(this.pcrCikis_Click);
            // 
            // pcrUcuslarim
            // 
            this.pcrUcuslarim.BackColor = System.Drawing.Color.Transparent;
            this.pcrUcuslarim.Image = ((System.Drawing.Image)(resources.GetObject("pcrUcuslarim.Image")));
            this.pcrUcuslarim.Location = new System.Drawing.Point(334, 3);
            this.pcrUcuslarim.Name = "pcrUcuslarim";
            this.pcrUcuslarim.Size = new System.Drawing.Size(60, 49);
            this.pcrUcuslarim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrUcuslarim.TabIndex = 3;
            this.pcrUcuslarim.TabStop = false;
            this.pcrUcuslarim.Click += new System.EventHandler(this.pcrUcuslarim_Click);
            // 
            // pcrAnasayfa
            // 
            this.pcrAnasayfa.BackColor = System.Drawing.Color.Transparent;
            this.pcrAnasayfa.Image = ((System.Drawing.Image)(resources.GetObject("pcrAnasayfa.Image")));
            this.pcrAnasayfa.Location = new System.Drawing.Point(65, 4);
            this.pcrAnasayfa.Name = "pcrAnasayfa";
            this.pcrAnasayfa.Size = new System.Drawing.Size(53, 48);
            this.pcrAnasayfa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrAnasayfa.TabIndex = 1;
            this.pcrAnasayfa.TabStop = false;
            this.pcrAnasayfa.Click += new System.EventHandler(this.pcrAnasayfa_Click);
            // 
            // pcrKampanya
            // 
            this.pcrKampanya.BackColor = System.Drawing.Color.Transparent;
            this.pcrKampanya.Image = ((System.Drawing.Image)(resources.GetObject("pcrKampanya.Image")));
            this.pcrKampanya.Location = new System.Drawing.Point(197, 3);
            this.pcrKampanya.Name = "pcrKampanya";
            this.pcrKampanya.Size = new System.Drawing.Size(57, 53);
            this.pcrKampanya.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrKampanya.TabIndex = 0;
            this.pcrKampanya.TabStop = false;
            this.pcrKampanya.Click += new System.EventHandler(this.pcrKampanya_Click);
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 800);
            this.Controls.Add(this.pnlButonlar);
            this.Controls.Add(this.pnlMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.frmMenu_Load);
            this.pnlButonlar.ResumeLayout(false);
            this.pnlButonlar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcrCikis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrUcuslarim)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrAnasayfa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrKampanya)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMenu;
        private System.Windows.Forms.Label lblÇıkış;
        private System.Windows.Forms.Label lblUcuslarım;
        private System.Windows.Forms.Label lblKampanya;
        private System.Windows.Forms.Label lblanasayfa;
        private System.Windows.Forms.Panel pnlButonlar;
        private System.Windows.Forms.PictureBox pcrCikis;
        private System.Windows.Forms.PictureBox pcrUcuslarim;
        private System.Windows.Forms.PictureBox pcrAnasayfa;
        private System.Windows.Forms.PictureBox pcrKampanya;
    }
}